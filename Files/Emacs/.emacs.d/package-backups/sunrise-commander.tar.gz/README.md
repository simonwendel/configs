Welcome to the Sunrise Commander Git repository. This is the place where you can
contribute directly to the development of the Sunrise Commander File Manager for
GNU Emacs.

If you don't know what the Sunrise Commander is, or just want to grab a copy to
use in your own Emacs please read [this Emacs Wiki page](http://www.emacswiki.org/emacs/Sunrise_Commander).

If you wish to contribute, please fork the project, commit your work to your own
branch and send me a pull request.

Happy hacking!
